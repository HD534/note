package com.andy.selenium.test;

import com.andy.selenium.test.util.ScreenShotUtil;
import com.andy.selenium.test.util.VariableUtil;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class CheckLock {

    private static final String DEFAULT_DRIVER_LOCATION = "C:\\AndyLin\\personal\\workspace\\selenium\\drivers\\chromedriver.exe";
    private static String outPutFolder = "C:\\AndyLin\\personal\\workspace\\selenium\\outputFolder";

    public static void main(String[] args) {

        if (args == null || args.length == 0) {
            throw new RuntimeException("Please input id format like 'id1,id2' in the first argument");
        }
        String idList = args[0];
        if (StringUtils.isEmpty(idList))
            throw new RuntimeException("Please input id format like 'id1,id2' in the first argument");
        String driver = DEFAULT_DRIVER_LOCATION;

        if (args.length > 1 && StringUtils.isNotEmpty(args[1])) {
            driver = args[1];
        }

        if (args.length > 2 && StringUtils.isNotEmpty(args[2])) {
            outPutFolder = args[2];
        }

        System.setProperty("webdriver.chrome.driver", driver);
        checkLock(idList);


    }

    private static void checkLock(String idList) {
        WebDriver driver = new ChromeDriver();
        driver.get("http://cigp3r8cweb01/aiait/");
        JavascriptExecutor js = (JavascriptExecutor) driver;

        js.executeScript("window.open('http://cigp3r8cweb01.aia.biz/tcs/clock_checkrec.asp','_blank');");
        try {
            TimeUnit.SECONDS.sleep(2);
            String[] split = idList.split(",");
            for (String id : split) {
                String openLink = "window.open('http://cigp3r8cweb01.aia.biz/tcs/clock_logrec.asp?Tuserid=" + id + "','_blank');";
                js.executeScript(openLink);
//                js.executeScript("window.open('http://cigp3r8cweb01.aia.biz/tcs/clock_logrec.asp?Tuserid=asnphtj','_blank');");
                TimeUnit.SECONDS.sleep(2);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            //reset step no
            ScreenShotUtil.resetNoOfSteps();
            //set variables
            VariableUtil.setOutPutFolder(outPutFolder);
            VariableUtil.setTestCaseName("test");
            VariableUtil.setTestCasePath("");
            driver.close();
            driver.quit();
        }
    }
}
