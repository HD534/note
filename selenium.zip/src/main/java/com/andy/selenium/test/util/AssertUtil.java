package com.andy.selenium.test.util;

public class AssertUtil {

    public static void assertCurrentTitleEquals(String expectedTitle, String errorMessage) {
        if (!expectedTitle.equals(SeleniumUtil.getCurrentTitle())) {
            throw new RuntimeException(errorMessage);
        }
    }

}
