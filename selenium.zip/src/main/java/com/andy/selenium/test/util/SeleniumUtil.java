package com.andy.selenium.test.util;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class SeleniumUtil {
	
	public static WebElement findElement(By by){
		try {
			WebElement result = DriverManager.getCurrentDriver().findElement(by);
			return result;
		} catch(NoSuchElementException ne){
			return null;
		}
	}

	public static String getCurrentTitle(){
        return DriverManager.getCurrentDriver().getTitle();
    }

	
	public static WebElement findElement(By by, String exceptionMsg){
		try {
			WebElement result = DriverManager.getCurrentDriver().findElement(by);
			return result;
		} catch(NoSuchElementException ne){
			
			throw new RuntimeException(exceptionMsg, ne);
		}
	}

	public static WebElement findElement(WebElement webElement, By by, String exceptionMsg){
		try {
			WebElement result = webElement.findElement(by);
			return result;
		} catch(NoSuchElementException ne){

			throw new RuntimeException(exceptionMsg, ne);
		}
	}
	
	public static List<WebElement> findElements(By by, String exceptionMsg){
		List<WebElement> list = DriverManager.getCurrentDriver().findElements(by);
		
		if(list.isEmpty()){
			throw new RuntimeException(exceptionMsg);
		}
		
		return list;
	}
	
	public static void openScreen(String url){
		
		if(!url.startsWith("/")){
			url = "/" + url;
		}
		
		DriverManager.getCurrentDriver().get(GeneralConfigUtil.getBaseUrl() + url);
		
		waitPageLoaded();
	}

    public static void openBaseUrl(){

        DriverManager.getCurrentDriver().get(GeneralConfigUtil.getBaseUrl());

        waitPageLoaded();
    }
	
	public static void waitPageLoaded(long waitTime){	
		
		
		//There is some scenarios that developer need to simulate user click a button. 
		//This button will submit something so that developer need to call this method to wait until the
		//page is refreshed. However, it is possible that after the button is clicked, the page refreshing
		//is not started at once(maybe the browser still executing some javascript). At this moment, the 
		//"document.readState" is "complete" so that below method will return at once even though the page is 
		//not refreshed yet. So, need to add below statement to wait 0.1 second to make sure the page refreshing
		//already start before we check the refreshing is completed.
		
		try {
			Thread.sleep(100L);
		} catch (InterruptedException e) {
				
		}
		
		
		waitPageLoadedNoDelay(waitTime);
		
	}
	
	public static void waitPageLoadedNoDelay(long waitTime){	
		new WebDriverWait(DriverManager.getCurrentDriver(), waitTime).until(
				ExpectedConditions.or(
					ExpectedConditions.alertIsPresent(),
					new ExpectedCondition<Boolean>() {
						public Boolean apply(WebDriver driver) {
							JavascriptExecutor js = (JavascriptExecutor) driver;
							return js.executeScript("return document.readyState;").equals("complete");
						}
					}
				)
			);
	}
	
	public static void waitPageLoaded(){	
		
		waitPageLoaded(GeneralConfigUtil.getTimeoutTime());

		try {
			Thread.sleep(4000L);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public static void waitPageLoadedNoDelay(){	
		waitPageLoadedNoDelay(GeneralConfigUtil.getTimeoutTime());
	}
	
	public static void switchToRootFrame(){
		DriverManager.getCurrentDriver().switchTo().defaultContent();  
	}
	
	private static void doSwitchToMainFrame(boolean wait) {
		
		switchToRootFrame();
		
		if(wait){
			waitPageLoadedNoDelay();
		}
		
		WebDriver driver = DriverManager.getCurrentDriver();
		WebElement frame = driver.findElement(By.xpath("//iframe[@id='main']"));
		if(frame == null){
			throw new RuntimeException("The main page is not loaded properly.");
		} 
		driver.switchTo().frame(frame);
		
		if(wait){
			waitPageLoadedNoDelay();
		}
		
		frame = driver.findElement(By.xpath("//frame[@id='lmain']"));
		if(frame == null){
			throw new RuntimeException("The main page is not loaded properly.");
		} 
		driver.switchTo().frame(frame);
		
		if(wait){
			waitPageLoadedNoDelay();
		}
		
	}
	
	public static void switchToMainFrame() {
		
		doSwitchToMainFrame(false);
		
	}
	
	public static void waitForMainFrameReady() {
		
		doSwitchToMainFrame(true);
		
	}
	
	public static void clickMainMenu(String menuItem){
		
		switchToRootFrame();
        
		WebElement menuButton = findElement(ElementLocator.byHook(menuItem),
											"Can not find menu item '" + menuItem + "'.");
		
		((JavascriptExecutor) DriverManager.getCurrentDriver()).executeScript(
	             "arguments[0].click()", menuButton);  
		 
		waitForMainFrameReady();
		 

    	LogUtil.info("click menu item '" + menuItem + "'");
        ScreenShotUtil.saveScreenShotForStep("click menu item " + menuItem);
        
	}
	
	/**
	 * Check whether whether current model dialog is closed. It is expected that when this method
	 * is called current window has been switch to an model dialog.  
	 * @return Return true when dialog is closed. Otherwise return false. 
	 */
	public static boolean isCurrentModelDialogClosed(){
		WebDriver driver = DriverManager.getCurrentDriver();
		
		try {
			driver.getWindowHandle();
		} catch(NoSuchWindowException nse){
			return true;
		}
		
		return false;
	}
	
	/**
	 * Close current model dialog. it is expected that this method is called when an model dialog
	 * is shown.
	 */
	public static void closeCurrentModelDialog(){
		JavascriptExecutor driver = (JavascriptExecutor) DriverManager.getCurrentDriver();
		driver.executeScript("window.close();");
	}
	
	public static void keyInDate(String dateValue, By by, String dateName){
		WebElement dateField = findElement(by, "Cannot find the field for '" + dateName + "'");
		
		String adjustedDate = ParseNFormatUtil.parseDateForKeyIn(dateValue, dateName);
		
		JavascriptExecutor driver = ((JavascriptExecutor) DriverManager.getCurrentDriver());
		driver.executeScript("arguments[0].value='"+adjustedDate +"'", dateField);
		
	}
	
	public static abstract class ModelDialogHandlingTemplate {
		
		protected abstract void manipulateDialog() ;
		
		protected abstract void openDialog();
		
		public void execute() {
			WebDriver driver = DriverManager.getCurrentDriver();
			
			String originalHandle = driver.getWindowHandle();
			
			Set<String> orgHandleSet = driver.getWindowHandles();
			openDialog();
			
			Set<String> newHandleSet = null;
			
			final Long sleepTime = 500L;
			final float sleepTimeSeconds = (sleepTime/1000L);
			final int loopingTimes = (int) ( GeneralConfigUtil.getTimeoutTime() / sleepTimeSeconds);
			
			//sometimes, the dialog just cannot opened soon(may caused by the server is not responsed soon) so that
			//we need below checking to make sure the dialog has been opened before other processing.
			for(int i = 0 ; i < loopingTimes || newHandleSet == null ; i++){
				newHandleSet = driver.getWindowHandles();
				//this is used to check whether the dialog has been open. If it is opened, a new handler is created so that
				//the size of newHandleSet is bigger than the original one.
				if(newHandleSet.size() > orgHandleSet.size()){
					break;
				}
				
				//if the dialog is still not opened just wait 0.5 second.
				try {
					Thread.sleep(sleepTime);
				} catch (InterruptedException e) {
					throw new RuntimeException(e);
				}
			}
			
			
			
			//find the new handle of the created dialog.
			String newHandle = null;
			for( String handle : newHandleSet){
				if(orgHandleSet.contains(handle)){
					continue;
				}
				
				newHandle = handle;
				break;
			}
			
			if(newHandle == null){
				throw new RuntimeException("The model dialog is not opened properly.");
			}
			
			driver.switchTo().window(newHandle);
			
			waitPageLoadedNoDelay();
			
			manipulateDialog();
			
			if(!isCurrentModelDialogClosed()){
				
				closeCurrentModelDialog();
			
			}
			driver.switchTo().window(originalHandle);
		}
		
	}
	
	/**
	 * This class is used to handle below scenario. 
	 * 1. Click a button to open a dialog
	 * 2. Key in one search criteria
	 * 3. Click a button to trigger searching
	 * 4. Click a row to select a result. Then the dialog will be closed automatically.
	 * 
	 * 
	 *
	 */
	public static abstract class SimpleSearchModelDialogTemplate extends ModelDialogHandlingTemplate{
		
		private String subject;
		private String errMsgForNoFound;
		
		
		
		public SimpleSearchModelDialogTemplate(String subject, String errMsgForNoFound) {
			super();
			this.subject = subject;
			this.errMsgForNoFound = errMsgForNoFound;
		}

		@Override
		protected void openDialog() {
			findPopupButton().click();
		}
		
		protected abstract WebElement findPopupButton();
		
		protected abstract void keyInSearchCriteria();
		
		protected abstract void triggerSearch();
		
		protected abstract List<WebElement> findResultList();
		
		/**
		 * 
		 * @param result
		 * @return true - means a record has been selected and dialog is closed. false - means will check next record should be selected or not.
		 */
		protected abstract boolean selectResult(WebElement result);
		
		@Override
		protected void manipulateDialog() {
			keyInSearchCriteria();
			triggerSearch();
			SeleniumUtil.waitPageLoaded();
			
			LogUtil.info("Search result for " + subject);
			ScreenShotUtil.saveScreenShotForStep("Search result for " + subject);
			
			List<WebElement> resultList = findResultList();
			
			for(WebElement result: resultList){
				
				if(selectResult(result)){
					return;
				}
				
			}
			
			throw new RuntimeException(errMsgForNoFound);
			
		}

		
		
	}
	
	public static abstract class AlertHandlingTemplate{
		private Long waitSeconds = 1L;
		
		public AlertHandlingTemplate(){
			super();
		}
		
		public AlertHandlingTemplate(Long waitSeconds){
			this.waitSeconds = waitSeconds;
		}
		
		protected Alert waitForAlert(){
			try{
				return new WebDriverWait(DriverManager.getCurrentDriver(), waitSeconds).until(ExpectedConditions.alertIsPresent());
			}catch(NoAlertPresentException noAlertExp){
				return null;
			}
			
		}
		
		
		
		public abstract boolean handle(Alert alert);
		
		public boolean execute(){
			Alert alert = waitForAlert();
			
			if(alert == null ){
				return false;
			}
			String logMsg = "'" + alert.getText() + "' is prompted.";
			boolean handled = handle(alert);
			
			if(handled){
				LogUtil.info(logMsg);
			}
			
			return true;
		}
		
	}
	
	public static class AlertHandlingChain{
		List<AlertHandlingTemplate> executionQueue = new ArrayList<AlertHandlingTemplate>();
		
		public AlertHandlingChain add(AlertHandlingTemplate handler){
			executionQueue.add(handler);
			return this;
		}
		
		public void execute(){
			List<AlertHandlingTemplate> exeQueue = executionQueue;
			
			for(int i = 0 ; i < exeQueue.size(); i++){
				if(!exeQueue.get(i).execute()){
					break;
				}
			}
		}
	}
	
	
}

