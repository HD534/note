package com.andy.selenium.test.util;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Iterator;
import java.util.Map;

public class ScreenShotUtil {
	
	private static ThreadLocal<Integer> noOfStep = new ThreadLocal<>();
	
	final private static String FILE_TYPE = "jpg";
	
	private static byte[] doCaptureScreen(TakesScreenshot element){
		byte[] rawData = element.getScreenshotAs(OutputType.BYTES);

		ByteArrayOutputStream result = new ByteArrayOutputStream();
		
		//compress the png data first. Otherwise the screen shot will be very big.
		BufferedImage originalImage = null;
		try {
		    originalImage = ImageIO.read(new ByteArrayInputStream(rawData));
		    
		    if(originalImage == null){
		    	LogUtil.warn("Cannot read raw image data with any registered image reader so do not compress.");
		    	return rawData;
		    }
		    
		    BufferedImage compressImage = new BufferedImage(originalImage.getWidth(), 
		    												originalImage.getHeight(),
		    												BufferedImage.TYPE_USHORT_555_RGB);
		    
		    Graphics2D g2d = (Graphics2D) compressImage.getGraphics();
		    g2d.drawImage(originalImage, 0, 0, null);
		    
		    ImageIO.write(compressImage, FILE_TYPE, result);
		    
		} catch (IOException e) {
			throw new RuntimeException("exception happen when the program try to compress screen shot.", e);
		}
		
		return result.toByteArray();
		
	}
	
	private static void increaseNoOfSteps(){
		noOfStep.set(noOfStep.get() + 1);
	}
	
	public static void resetNoOfSteps(){
		noOfStep.set(1);
	}
	
	private static String adjustFileName(String fileName){
		DecimalFormat format = new DecimalFormat("0000");
		
		String prefix = format.format(noOfStep.get());
		
		return prefix + "_" + fileName + "." + FILE_TYPE;
	}
	
	public static void saveScreenShotForStep(String fileName){
		String adjustedFileName = adjustFileName(fileName);
		increaseNoOfSteps();

		byte[] picData = doCaptureScreen((TakesScreenshot) DriverManager.getCurrentDriver());

		FileUtil.writeToFileUnderTestCaseFolder(picData, adjustedFileName);

		logScreenShot(adjustedFileName);
	}

	public static void saveScreenShotForStep(String fileName, WebElement element) {

        String adjustedFileName = adjustFileName(fileName);
        increaseNoOfSteps();

        byte[] picData = doCaptureScreen(element);

        FileUtil.writeToFileUnderTestCaseFolder(picData, adjustedFileName);

        logScreenShot(adjustedFileName);

	}
	
	private static void logScreenShot(String adjustedFileName){
		String relatedPath = FileUtil.generateTestCaseFolderRelatedPath(VariableUtil.getTestCasePath(), 
												   				        VariableUtil.getTestCaseName());
		
		String html = "<img style='width:100%;' src='" + relatedPath + adjustedFileName + "' />";
		
		LogUtil.html(html);
		
	}
	
	private static String getScreenShotFileNameForError(String browserName){
		return adjustFileName("ERR_" + browserName );
	}
	
	public static void saveScreenShotForError(){
		
		Map<String, WebDriver> driverMap = DriverManager.getAllDrivers();
		
		for(Iterator<String> it = driverMap.keySet().iterator(); it.hasNext(); ){
			String browserName = it.next();
			WebDriver driver = driverMap.get(browserName);
			
			String adjustedFileName = getScreenShotFileNameForError(browserName );
			
			LogUtil.info("Capture screen shot for browser " + browserName);
			
			byte[] picData = doCaptureScreen((TakesScreenshot) driver);
			
			FileUtil.writeToFileUnderTestCaseFolder(picData, adjustedFileName);
			
			logScreenShot(adjustedFileName);
			
			LogUtil.debug("Page source for browser " + browserName + " : \n\r" + driver.getPageSource());
			
		}
		
		
	}
	
	
	
}
