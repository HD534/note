package com.andy.selenium.test.util;

import java.util.HashMap;
import java.util.Map;

public class VariableUtil {
	
	private static ThreadLocal<Map<String, Object>> variableMap = new ThreadLocal<Map<String, Object>>();
	
	
	
	final private static String TEST_CASE_STATUS = "TEST_CASE_STATUS";
	
	final private static String TEST_CASE_NAME = "TEST_CASE_NAME";
	
	final private static String TEST_CASE_PATH = "TEST_CASE_PATH";
	
	final private static String OUTPUT_FOLDER = "OUTPUT_FOLDER";
	
	
	private static Map<String, Object> getVariableMap(){
		Map<String, Object> result = variableMap.get();
		
		if(result == null){
			result = new HashMap<String, Object>();
			variableMap.set(result);
		}
		
		return result;
	}
	
	private static Object getValue(String varName){
		return getVariableMap().get(varName);
	}
	
	private static void setValue(String varName, Object value){
		getVariableMap().put(varName, value);
	}
	
	public static String getTestCaseStatus() {
		return (String) getValue(TEST_CASE_STATUS);
	}

	public static void setTestCaseStatus(String status) {
		setValue(TEST_CASE_STATUS, status);
	}
	
	public static String getTestCaseName() {
		return (String) getValue(TEST_CASE_NAME);
	}

	public static void setTestCaseName(String testCaseName) {
		setValue(TEST_CASE_NAME, testCaseName);
	}

	public static String getTestCasePath() {
		return (String) getValue(TEST_CASE_PATH);
	}

	public static void setTestCasePath(String testCasePath) {
		setValue(TEST_CASE_PATH, testCasePath);
	}

	public static String getOutPutFolder() {
		return (String) getValue(OUTPUT_FOLDER);
	}

	public static void setOutPutFolder(String outPutFolder) {
		setValue(OUTPUT_FOLDER, outPutFolder);
	}
	
	
	
}
