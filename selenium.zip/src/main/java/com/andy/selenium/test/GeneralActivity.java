package com.andy.selenium.test;

import com.andy.selenium.test.util.*;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.concurrent.TimeUnit;

import static com.andy.selenium.test.util.AssertUtil.assertCurrentTitleEquals;
import static com.andy.selenium.test.util.DriverManager.getCurrentDriver;
import static com.andy.selenium.test.util.SeleniumUtil.findElement;

public class GeneralActivity {


    public static void search(String keywords) {

        WebDriver driver = new ChromeDriver();
        driver.get("http://www.baidu.com");
        driver.findElement(new By.ById("kw")).sendKeys(keywords);
        WebElement su = driver.findElement(new By.ById("su"));
        su.click();
        try {
            TimeUnit.SECONDS.sleep(2);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        driver.close();
//        WebElement kw = SeleniumUtil.findElement();

    }

    public static void login(String username, String password) {

        WebDriver driver = new ChromeDriver();
        driver.get("https://vitalityuat2.aia.com.sg/en/my-aia/login.html");


        driver.findElement(new By.ById("aia1615612124")).sendKeys(username);
        driver.findElement(new By.ByXPath("//input[@id='aia1223969016']")).sendKeys(password);
        driver.findElement(new By.ByXPath("//button[@type = 'button' and (text() = 'SUBMIT' or . = 'SUBMIT')]")).click();

        //显式等待， 针对某个元素等待
        WebDriverWait wait = new WebDriverWait(driver, 5, 1);
        String text = wait.until(
                webDriver -> webDriver.findElement(new By.ByXPath("/html/body/div[3]/div/div[3]/div/div/div/div[2]/div/p"))
        ).getText();

        Assert.assertEquals("WELCOME!", text);

        driver.close();
    }

    public static void loginTC001(String userName, String password) {
        SeleniumUtil.openBaseUrl();
        assertCurrentTitleEquals("Login", "The login screen is not opened properly.");
        LogUtil.info("login as user name = " + userName + ". Password = " + password);
        findElement(By.id("aia1615612124"),
                "Cannot find user name input field").sendKeys(userName);
        findElement(By.xpath("//input[@id='aia1223969016']"),
                "Cannot find password input field").sendKeys(password);
        findElement(By.xpath("//button[@type = 'button' and (text() = 'SUBMIT' or . = 'SUBMIT')]"),
                "Cannot find login submit button").click();

        SeleniumUtil.waitPageLoaded();
        SeleniumUtil.findElement(By.xpath("/html/body/div[3]/div/div[3]/div/div/div/div[2]/div/p"),
                "Fail to login with user " + userName + " ,password " + password);
        ScreenShotUtil.saveScreenShotForStep("Login Page");
        getCurrentDriver().close();
    }

    public static void loginTC002() {
        SeleniumUtil.openBaseUrl();
        assertCurrentTitleEquals("Login", "The login screen is not opened properly.");
        findElement(By.xpath("//a[contains(text(),'Forgot your Password?')]"),
                "Cannot find Forgot your Password button").click();

        SeleniumUtil.waitPageLoaded();
        assertCurrentTitleEquals("AIA Vitality Forgot Password", "The Forgot Password screen is not opened properly.");
        ScreenShotUtil.saveScreenShotForStep("Forgot Password Page");
        getCurrentDriver().close();
    }


    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "C:\\AndyLin\\personal\\workspace\\selenium\\drivers\\chromedriver.exe");
        checkLock();
//        login("G3202637F","Aa123456789!");
//        System.setProperty("phantomjs.binary.path", "D:\\AndyLin\\workspace\\selenium\\drivers\\phantomjs.exe");
//        switchToBrowser("phantomJSDriver");
        //reset step no
        ScreenShotUtil.resetNoOfSteps();
        //set variables
        VariableUtil.setOutPutFolder("D:\\AndyLin\\workspace\\selenium\\outputFolder");
        VariableUtil.setTestCaseName("test");
        VariableUtil.setTestCasePath("");

//        loginTC002();
    }

    private static void checkLock() {
        WebDriver driver = new ChromeDriver();
        driver.get("http://cigp3r8cweb01/aiait/");
        JavascriptExecutor js = (JavascriptExecutor) driver;

//        "http://cigp3r8cweb01.aia.biz/tcs/clock_checkrec.asp"
        js.executeScript("window.open('http://cigp3r8cweb01.aia.biz/tcs/clock_checkrec.asp','_blank');");
        try {
            TimeUnit.SECONDS.sleep(2);
            js.executeScript("window.open('http://cigp3r8cweb01.aia.biz/tcs/clock_logrec.asp?Tuserid=asnphtj','_blank');");
            TimeUnit.SECONDS.sleep(3);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            driver.close();
            driver.quit();
        }
    }


    public static void closeApplication() {

        DriverManager.closeAllBrowser();

    }

    public static void captureTestCaseName(String path, String caseName) {

        VariableUtil.setTestCaseName(caseName);
        VariableUtil.setTestCasePath(path);
    }

    public static void captureOutPutFolder(String folder) {
        VariableUtil.setOutPutFolder(folder);
    }

    public static void captureTestCaseStatus(String status) {
        VariableUtil.setTestCaseStatus(status);
    }

    public static void resetStepNumber() {
        ScreenShotUtil.resetNoOfSteps();
    }

    private static boolean isTestCasePassed() {
        return "PASS".equals(VariableUtil.getTestCaseStatus());
    }

    public static void captureScreenShotForError() {
        if (!isTestCasePassed()) {
            ScreenShotUtil.saveScreenShotForError();
        }
    }

}
