package com.andy.selenium.test.util;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;

public class ElementLocator  {
	
	public static By byHook(final String hookName) {
		return new ByHook(hookName);
	}
	
	public static By beforeHook(final String hookName) {
		return new BeforeHook(hookName);
	}
	
	public static class ByHook extends ByXPath {
		
		private static final long serialVersionUID = 8903467016613447294L;

		public ByHook(String hookName) {
			super("//*[@athook='" + hookName + "']");
	
		}
	
		
	}
	
	public static class BeforeHook extends ByXPath {
		
		private static final long serialVersionUID = 8903467016613447294L;

		public BeforeHook(String hookName) {
			super("//div[@athook='" + hookName + "']/preceding-sibling::input[1]");
	
		}
	
		
	}
	
}
