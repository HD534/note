package com.andy.selenium.test.util;

import java.io.BufferedWriter;
import java.io.IOException;
import java.util.Map;

public class RobotListener {
	public static final int ROBOT_LISTENER_API_VERSION = 2;
	public static final String DEFAULT_FILENAME = "d:/listen_java.txt";
	 
	 
	private BufferedWriter outfile = null;
	
	public RobotListener() throws IOException{
//		outfile = new BufferedWriter(new FileWriter(DEFAULT_FILENAME));
	}
	
	public void endTest(String name, Map attrs) throws IOException {
        
		/*
		
		//String status = attrs.get("status").toString();
		outfile.write("endTest name = " + name);
        outfile.newLine();
        outfile.write("attrs = " + attrs);
        outfile.newLine();
        outfile.write("variable " + VariableUtil.getTestCaseStatus() + System.currentTimeMillis());
        outfile.flush();
        */
    }
}
