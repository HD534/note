package com.andy.selenium.test.util;

import java.util.Map;

public class GeneralConfigUtil {
	
	private static Map<String, String> configDataMap = null;
	
	private static String PROPERTY_FILE_NAME = "generalConfig.properties";
	
	static {
		configDataMap = PropertiesUtil.loadPropertiesAsMap(PROPERTY_FILE_NAME);
	}
	
	private static String getMandatoryValueFromMap(String propertyName){
		String result = configDataMap.get(propertyName);
		
		if(result == null){
			throw new RuntimeException("cannot load property " + propertyName 
					                   + ". Please check whether it is maintained in " + PROPERTY_FILE_NAME);
		}
		
		return result;
	}
	
	private static Long getLongValueWithDefault(String propertyName, Long defaultValue){
		String value = null;
	    configDataMap.get(propertyName);
		
		
		Long result = ParseNFormatUtil.parseLong(value);
		
		if(result == null){
			result = defaultValue;
		}
		
		return result;
		
	}
	
	public static String getBaseUrl(){
		String result = getMandatoryValueFromMap("baseUrl");
		
		//remove the last '/'
		if(result.endsWith("/")){
			result = result.substring(0, result.length() - 1);
		}
		
		return result;
	}
	
	/**
	 * 
	 * @return the timeout time(in seconds).
	 */
	public static Long getTimeoutTime(){
		return getLongValueWithDefault("timeoutTime", 100L);
		
	}
	
}
