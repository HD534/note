package com.andy.selenium.test.util;

import java.util.*;

public class PropertiesUtil {
	
	public static Properties loadProperties(String fileName){
		
		Properties pps = new Properties();
		try{	
			pps.load(PropertiesUtil.class.getClassLoader().getResourceAsStream(fileName));
		}catch(Exception e){
			throw new RuntimeException("cannot load properties file " + fileName, e);
		}
		
		return pps;
		
	}
	
	public static Map<String, String> loadPropertiesAsMap(String fileName){
		Properties pps = loadProperties(fileName);
		
		Map<String, String> result = new HashMap<String, String>();
		
		Set<Object> nameSet = pps.keySet();
		for(Iterator<Object> it = nameSet.iterator(); it.hasNext(); ) {
			String name = (String) it.next();
			String value = pps.getProperty(name);
			
			result.put(name, value);
			
		}
		return result;
	}
	
}
