package com.andy.selenium.test.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class FileUtil {
	
	public static void writeToFile(byte[] data, File file) {
		FileOutputStream output = null;
		
		try {
			output = new FileOutputStream(file);
			output.write(data);
		} catch (FileNotFoundException e) {
			throw new RuntimeException(e);
		} catch(IOException ie){
			throw new RuntimeException(ie);
		} finally {
			try {
				output.close();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
		
		
		
	}
	
	public static void writeToFileUnderTestCaseFolder(byte[] data, String fileName) {
		
		writeToFile(data, new File(getCurrentTestCaseFolder(), fileName));
		
	}
	
	public static File getCurrentTestCaseFolder(){
		
		return createTestCaseFolder(VariableUtil.getOutPutFolder(), 
				                    VariableUtil.getTestCasePath(), 
				                    VariableUtil.getTestCaseName());
		
	}
	
	public static File createTestCaseFolder(String outputFolderPath, String testCasePath, String testCaseName){
		File outputFolder = new File(outputFolderPath);
		
		if(!outputFolder.isDirectory()){
			throw new RuntimeException("the output folder is not exist. The path of output folder is:" + 
									    outputFolderPath);
		}
		
		List<String> subFolderList = parseTestCasePath(testCasePath);
		
		subFolderList.add(testCaseName);
		
		File subFolder = outputFolder;
		
		for(int i = 0; i < subFolderList.size(); i++){
			subFolder = new File(subFolder, subFolderList.get(i));
			
			if(subFolder.isFile()){
				throw new RuntimeException("It is expected that " + subFolder + " is a folder.");
			}
			
			if(!subFolder.exists()){
				subFolder.mkdirs();
			}
		}
		
		return subFolder;
		
	}
	
	
	public static String generateTestCaseFolderRelatedPath(String testCasePath, String testCaseName){
				
		List<String> subFolderList = parseTestCasePath(testCasePath);
		
		subFolderList.add(testCaseName);
		
		StringBuffer result = new StringBuffer();
		
		for(int i = 0; i < subFolderList.size(); i++){
			result.append(subFolderList.get(i));
			result.append("/");
			
			
		}
		
		return result.toString();
		
	}
	
	private static List<String> parseTestCasePath(String testCasePath){
		List<String> result = new ArrayList<>();
		
		if(testCasePath == null || "".equals(testCasePath.trim())){
			return result;
		}
		
		StringTokenizer token = new StringTokenizer(testCasePath,".");
		
		while(token.hasMoreTokens()){
			result.add(token.nextToken());
		}
		
		return result;
	}
}
