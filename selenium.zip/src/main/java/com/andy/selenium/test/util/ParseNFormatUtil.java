package com.andy.selenium.test.util;

import java.util.Map;

public class ParseNFormatUtil {
	
	public static Long parseLong(String str){
        Long result = null;
        if(str == null || "".equals(str)){
            return null;
        }
        try{
            result = Long.parseLong(str);
        }catch(NumberFormatException e){
            return null;
        }
        
        return result;
    }
	
	public static String parseDateForKeyIn(String input, String dateFieldName){
		
		if(input == null){
			input = "";
		}
		
		return input;
		
		/*
		DateFormat inputFormat = new SimpleDateFormat("dd/MM/yyyy");
		DateFormat outputFormat = new SimpleDateFormat("ddMMyyyy");
		
		Date date = null;
		try{
			date = inputFormat.parse(input);
		}catch(ParseException pe){
			throw new RuntimeException("The format of '" + dateFieldName + "' is not valid." + 
		                               " The invalid date value is '" + input + "'");
		}
		
		return outputFormat.format(date);
		*/
		
	}
	
	
	
	public static String formatFreeKeywords(Map<String, String> fieldMap) {
		StringBuffer result = new StringBuffer();
		for(String key : fieldMap.keySet()){
			if(result.length() > 0) {
				result.append("; ");
			}
			result.append(key);
			result.append("=");
			result.append(fieldMap.get(key));
		}
		
		return result.toString();
		
	}
	
}
