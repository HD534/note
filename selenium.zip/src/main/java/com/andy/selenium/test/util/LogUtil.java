package com.andy.selenium.test.util;

public class LogUtil {
	private static void generateLog(String level, String msg){
		System.out.println("*" + level + "* " + msg);
	}
	
	public static void error(String msg){
		generateLog("ERROR", msg);
	}
	
	public static void debug(String msg){
		generateLog("DEBUG", msg);
	}

	public static void info(String msg){
		generateLog("INFO", msg);
	}
	
	public static void html(String msg){
		generateLog("HTML", msg);
	} 
	
	public static void warn(String msg){
		generateLog("WARN", msg);
	}
}
