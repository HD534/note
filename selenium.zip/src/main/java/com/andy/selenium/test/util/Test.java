package com.andy.selenium.test.util;

import java.util.Iterator;
import java.util.Map;

public class Test {

	public static void main(String[] args) {
		Map<String, String> map = PropertiesUtil.loadPropertiesAsMap("userPassword.properties");
		
		Iterator<String> it = map.keySet().iterator();
		while(it.hasNext()){
			System.out.println(map.get(it.next()));
		}
	}

}
