package com.andy.selenium.test.util;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Provide WebDriver instance for other keyword implemented in JAVA.
 * This class will cache WebDriver in thread local object so that different keywords run in the same
 * thread can get the same instance of WebDriver.
 * All keywords should get WebDriver instance from this class but not create them with "new".
 */
public class DriverManager {

    private static final String DEFAULT_BROWSER_NAME = "DEFAULT_BROWSER";

    private static ThreadLocal<Map<String, WebDriver>> driverCache = new ThreadLocal<Map<String, WebDriver>>();
    private static ThreadLocal<String> currentBrowserName = new ThreadLocal<String>();

    static {
        HashMap<String, WebDriver> stringWebDriverHashMap = new HashMap<>();
        PhantomJSDriver value = new PhantomJSDriver();
        value.manage().window().maximize();
        stringWebDriverHashMap.put("phantomJSDriver", value);

        driverCache.set(stringWebDriverHashMap);
        currentBrowserName.set(DEFAULT_BROWSER_NAME);
    }


    /**
     * Get an instance of WebDriver from cache. If there there is no instance in the cache, create a new one.
     * This method will switch the cached browser name to parameter browserName.
     *
     * @param browserName It possible that one test case manipulate multiple browsers so that it is necessary
     *                     to assign a name that link to the returned WebDriver. When a WebDriver is created with a
     *                     name, it can be retrieved from the cache with the same name later.
     *
     * @return A WebDriver instance that is available for testing.
     * @see DriverManager#switchToBrowser(String)
     */
    public static WebDriver getCurrentDriver(String browserName){

        //for those who use zip version of Chrome, need to set chrome driver. Otherwise, can comment out below line.
//        System.setProperty("webdriver.chrome.driver", "C:\\Software\\chrome-win\\chromedriver.exe");

        Map<String, WebDriver> driverMap = driverCache.get();

        WebDriver driver = driverMap.get(browserName);

        if(driver == null){

            ChromeOptions options = new ChromeOptions();
            options.addArguments("--start-maximized"); // open Browser in maximized mode
            options.addArguments("disable-infobars"); // disabling infobars
            options.addArguments("--disable-extensions"); // disabling extensions
            options.addArguments("--disable-gpu"); // applicable to windows os only
            options.addArguments("--disable-dev-shm-usage"); // overcome limited resource problems
            options.addArguments("--no-sandbox"); // Bypass OS security model

            driver = new ChromeDriver(options);

            //if the element is not availabe, the findElement API should be return in very short time
            //If you need to wait for some elements, please use explicit waiting.
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.MICROSECONDS);

            driverMap.put(browserName, driver);
        }

        switchToBrowser(browserName);

        return driver;
    }

    /**
     * Use the current browser name in cache to call {@link DriverManager#getCurrentDriver(String)}.
     *
     */
    public static WebDriver getCurrentDriver(){
        return getCurrentDriver(currentBrowserName.get());
    }

    /**
     * It is possible that one test case need to manipulate multiple browser
     * This class cache a current browser name in thread local. This method is used to change the browser name in
     * cache. Once browser name is changed the {@link DriverManager#getCurrentDriver()} will always use the
     * cached browser name to retrieve WebDriver instance from cache.
     * @param browserName the browser name that will be saved in cache.
     *
     */
    public static void switchToBrowser(String browserName){
        if(browserName == null){
            currentBrowserName.set(DEFAULT_BROWSER_NAME);
        } else {
            currentBrowserName.set(browserName);
        }
    }

    /**
     * Close all WebDriver instance in cache and clear the cache.
     * Usually, this method should be called in tear down processing.
     */
    public static void closeAllBrowser(){
        Map<String, WebDriver> driverMap = driverCache.get();
        
        for(Iterator<WebDriver> it = driverMap.values().iterator(); it.hasNext(); ){
        	it.next().quit();
        }
        

        driverMap.clear();
    }
    
    public static Map<String, WebDriver> getAllDrivers(){
    	
    	Map<String, WebDriver> result = new HashMap<String, WebDriver>();
    	
    	result.putAll(driverCache.get());
    	
    	return result;
    	
    }

}
